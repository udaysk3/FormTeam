export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyCnzeXY4j7JOI738MSqoW9AEeqrxjnfRAQ",
    authDomain: "angular-ecart.firebaseapp.com",
    databaseURL: "https://angular-ecart.firebaseio.com",
    projectId: "angular-ecart",
    storageBucket: "angular-ecart.appspot.com",
    messagingSenderId: "258524817806",
    appId: "1:258524817806:web:6e38c03411016fcfd5dcdf",
    measurementId: "G-VMR46J6FKS"
  }
};

